<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zemlja extends Model
{
    protected $table = 'zemlja';
    protected $guarded = [];
}
