<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VrstaUsluge extends Model
{
    protected $table = 'vrsta_usluge';
    protected $guarded = [];
}
