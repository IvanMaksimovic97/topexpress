<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cenovnik extends Model
{
    protected $table = 'cenovnik';
    protected $guarded = [];
}
