<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NacinPlacanja extends Model
{
    protected $table = 'nacin_placanja';
    protected $guarded = [];
}
